//Name: Rudmila Shehrin Khan     ID: 130376205

function validate(event) {
  // TODO - write custom validation logic to validate the longitude and latitude
  // values. The latitude value must be a number between -90 and 90; the
  // longitude value must be a number between -180 and 180. If either/both are
  // invalid, show the appropriate error message in the form, and stop the 
  // form from being submitted. If both values are valid, allow the form to be
  // submitted.
 console.log('TODO - validate the longitude, latitude values before submitting');
 
//latitude
var latitudeElement= document.querySelector("#latID2");
var latitudeErrorElement= document.querySelector("#latErr");
var trimLengthLat=latitudeElement.value.trim().length;

//longitude
var longitudeElement= document.querySelector("#lonID2").value;
var longitudeErrorElement = document.querySelector("#lonErr");
var trimLengthLong=longitudeElement.trim().length;

//latitude
if(latitudeElement.value>90||isNaN(latitudeElement.value)==booVar||latitudeElement.value<-90||trimLengthLat==0){
  latitudeErrorElement.innerHTML=" must be a valid latitude (-90 to 90)";
  booVar=false;
  return booVar;
}
else{
  latitudeErrorElement.innerHTML="";
}

//longitude
var booVar=true;
if(longitudeElement<-180||isNaN(longitudeElement)==booVar||longitudeElement>180||trimLengthLong==0){
  longitudeErrorElement.innerHTML=" must be a valid longitude (-180 to 180)";
  booVar=false;
  return booVar;
}
else{
  longitudeErrorElement.innerHTML="";
}

return true;
}

// Wait for the window to load, then set up the submit event handler for the form.
window.onload = function() {
  const form = document.querySelector('form');
  form.onsubmit = validate;
};
